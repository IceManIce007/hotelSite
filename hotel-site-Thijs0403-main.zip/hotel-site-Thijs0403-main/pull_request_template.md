# Omschrijving

Omschrijf kort de wijzigingen die relevant zijn voor het issue en koppel deze aan de pull request

Fixes # (issue nummer)

# Test scenario

Voeg hieronder het uit te voeren test scenario toe zoals omschreven op de user story:

# Checklist:

- [ ] Code volgt de Code Conventions
- [ ] Ik heb mijn eigen code gereviewd
- [ ] Ik heb commentaar toegevoegd aan mijn code
- [ ] Ik heb de documentatie (user-story, ontwerp, testen, verbetervoorstel) bijgewerkt
- [ ] Ik heb een functionele test uitgevoerd volgens het test scenario

